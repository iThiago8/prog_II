<?php

class ConexaoDB {
    private string $connectionString;

    public function conectar(): void{

    }
}