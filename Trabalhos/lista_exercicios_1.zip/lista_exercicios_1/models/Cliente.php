<?php

class Cliente {
    public string $nome;
    protected string $cpf;
    private string $telefone;
}