<?php

class Funcionario {
    public string $nome;
    protected float $salario;
}